import React, { useState } from 'react';
import axios from 'axios';
import user_icon from 'C:/Users/Simon PC/Documents/Concordia 2023 2026/Winter 2025/SOEN 341/NPB-SOEN341_Project_W25-main_modified/chatapp/client/src/assets/person.png';
import email_icon from 'C:/Users/Simon PC/Documents/Concordia 2023 2026/Winter 2025/SOEN 341/NPB-SOEN341_Project_W25-main_modified/chatapp/client/src/assets/email.png';
import password_icon from 'C:/Users/Simon PC/Documents/Concordia 2023 2026/Winter 2025/SOEN 341/NPB-SOEN341_Project_W25-main_modified/chatapp/client/src/assets/password.png';
import 'C:/Users/Simon PC/Documents/Concordia 2023 2026/Winter 2025/SOEN 341/NPB-SOEN341_Project_W25-main_modified/chatapp/client/src/Styling/LoginPage.css'

function LoginPage() {
    const [username, setUsername] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [action,setAction] = useState("Login");

    const handleLogin = async (e) => {
        e.preventDefault();
        try {
            const response = await axios.post('http://localhost:3001/register', { username, email, password });
            alert(response.data);
        } catch (error) {
            console.error(error);
        }
    };
    return (
        <div className="container">
        <div className="header">
          <h2 className="title">{action}</h2>
          
          {/* {error && <p className="text-red-500 text-sm mb-2">{error}</p>} */}
  
          <div className="inputs">
            {action==="Login"?<div></div>:  <div className="input">
            <img src={user_icon}></img>
            <input type="text" placeholder="Name"></input>
          </div>}
        
  
          <form onSubmit={handleLogin} className="flex flex-col">
            <div className="input">
            <img src={email_icon}></img>
            <input
              type="email"
              placeholder="Email"
              className="border p-2 rounded mb-2"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
            </div>
            <div className="input">
            <img src={password_icon}></img>
            <input
              type="password"
              placeholder="Password"
              className="border p-2 rounded mb-4"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
            </div>
  {/* 
            <button type="submit" className="bg-blue-500 text-white p-2 rounded hover:bg-blue-600">
              Login
            </button> */}
            
          </form>
        </div> 
        {action==="Sign Up"?<div></div>:<div className="forgot-password">Forgot Password? <span>Click here!</span></div>
  }
        <div className="submit-container">
          <div className={action==="Login"?"submit gray":"submit"} onClick={() => {setAction("Login")}}>Sign Up</div>
          <div className={action==="Sign Up"?"submit gray":"submit"} onClick={() => {setAction("Sign Up")}}>Login</div>
  
        </div>
        </div>
      </div>
      );
    };
    
export default LoginPage;
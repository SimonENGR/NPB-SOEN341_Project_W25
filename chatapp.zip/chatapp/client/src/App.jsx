import React from "react";
import LoginPage from "./Pages/LoginPage";

function App() {
  return <LoginPage />;
}

export default App;
